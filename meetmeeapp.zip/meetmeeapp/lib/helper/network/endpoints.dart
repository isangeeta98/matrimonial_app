class Endpoints {
  static const String baseURL = "http://65.2.137.114:5000/api/";
  //static const String baseURL = "http://13.127.179.199:5000/api/";
  static const String register = "front/sign-up/";
  static const String login = "front/login";
  static const String userprofile = "front/user-comman-api/get-my-profile";
}