// To parse this JSON data, do
//
//     final shortListUserResponseModel = shortListUserResponseModelFromJson(jsonString);

import 'dart:convert';

ShortListUserResponseModel shortListUserResponseModelFromJson(String str) => ShortListUserResponseModel.fromJson(json.decode(str));

String shortListUserResponseModelToJson(ShortListUserResponseModel data) => json.encode(data.toJson());

class ShortListUserResponseModel {
  ShortListUserResponseModel({
    this.post,
  });

  List<Post>? post;

  factory ShortListUserResponseModel.fromJson(Map<String, dynamic> json) => ShortListUserResponseModel(
    post: List<Post>.from(json["post"].map((x) => Post.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "post": List<dynamic>.from(post!.map((x) => x.toJson())),
  };
}

class Post {
  Post({
    this.id,
    this.slUserId,
    this.slShortlistUserId,
    this.slStatus,
    this.slCreatedAt,
    this.slUpdatedAt,
    this.slDeleted,
    this.v,
  });

  String? id;
  SlUserId? slUserId;
  String? slShortlistUserId;
  int? slStatus;
  DateTime? slCreatedAt;
  DateTime? slUpdatedAt;
  bool? slDeleted;
  int? v;

  factory Post.fromJson(Map<String, dynamic> json) => Post(
    id: json["_id"],
    slUserId: slUserIdValues.map[json["sl_userId"]]!,
    slShortlistUserId: json["sl_shortlist_userId"],
    slStatus: json["sl_status"],
    slCreatedAt: DateTime.parse(json["sl_created_at"]),
    slUpdatedAt: DateTime.parse(json["sl_updated_at"]),
    slDeleted: json["sl_deleted"],
    v: json["__v"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "sl_userId": slUserIdValues.reverse[slUserId],
    "sl_shortlist_userId": slShortlistUserId,
    "sl_status": slStatus,
    "sl_created_at": slCreatedAt?.toIso8601String(),
    "sl_updated_at": slUpdatedAt?.toIso8601String(),
    "sl_deleted": slDeleted,
    "__v": v,
  };
}

enum SlUserId { SL_USER_ID, SL_USER_ID2, SL_USER_ID3, THE_6437_F86524_F4_B75_FA9223_E8_A }

final slUserIdValues = EnumValues({
  "sl_userId": SlUserId.SL_USER_ID,
  "sl_userId2": SlUserId.SL_USER_ID2,
  "sl_userId3": SlUserId.SL_USER_ID3,
  "6437f86524f4b75fa9223e8a": SlUserId.THE_6437_F86524_F4_B75_FA9223_E8_A
});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
