class Constants {
  static const String token = 'TOKEN';
  static const String userNameSaved = 'USERNAME';
  static const String email = 'Email';
  static const String oldpassword ="OLDPASSWORD";

  static const String loginStatus = "LOGIN_STATUS";
}