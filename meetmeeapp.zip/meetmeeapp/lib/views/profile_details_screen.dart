import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:meetmeapp/models/get_all_user_response_model.dart';

import '../constants/app_constants.dart';
import '../constants/string_constants.dart';
import '../controller/save_info_controller/save_family_detail_controller.dart';
import '../controller/all_user_controller/shortlist_block_abuse_controller.dart';
import '../elements/column_builder.dart';
import 'call/call_screen.dart';

class ProfileDetailScreen extends StatefulWidget {
  final Joindatum? userdetaildata;
  String? userid;
  ProfileDetailScreen({Key? key, this.userdetaildata, this.userid}) : super(key: key);

  @override
  State<ProfileDetailScreen> createState() => _ProfileDetailScreenState();
}

class _ProfileDetailScreenState extends State<ProfileDetailScreen> {
  ShortListController shortListController = Get.put(ShortListController());
  final _formKeyPersonal = GlobalKey<FormState>();
  String isSelected = 'personalInfo';
  bool isTap = false;
  int? starStatus;
  bool blockisTap = false;
  int? blockStatus;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: nestedScrollView(),
    );
  }
  nestedScrollView() {
    //toSendWhoVisitedProfile();
    return NestedScrollView(
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return [
          SliverAppBar(
            expandedHeight: MediaQuery.of(context).size.height * 0.25,
            titleSpacing: 0,
            backgroundColor: primaryColor,
            pinned: true,
            leading: InkWell(
              onTap: () => Navigator.pop(context),
              child: const Icon(
                Icons.arrow_back_ios,
                color: whiteColor,
              ),
            ),
            title: Text(
              "${widget.userdetaildata?.fristname} ${widget.userdetaildata?.middlename} ${widget.userdetaildata?.lastname}",
              style: white20BoldTextStyle,
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                        "assets/images/users/user7.png",
                   // fit: BoxFit.cover,
                  ),fit: BoxFit.cover)),
                child: Container(
                  color: blackColor.withOpacity(0.3),
                ),
              ),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(50),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: fixPadding * 2.0,
                  vertical: fixPadding,
                ),
                child: Row(
                  children: [
                    Column(
                      children: [
                        InkWell(
                          onTap: () async {
                            if (isTap) {
                              setState(() {
                                starStatus = 0;
                              });

                            }
                            else {
                              setState(() {
                                starStatus = 1;
                              });
                              shortListController.saveshortlistdata(refresh: true,
                              sl_userId: widget.userid,
                              sl_shortlist_userId: widget.userdetaildata?.id);
                            }
                            // AddToFav? favData = await Upgradeservice()
                            //     .addRemoveFav(LoggedUID.current_UID, widget.id,
                            //     starStatus.toString());
                            //print("favData ${favData?.favstatus}");
                            setState(() {
                              isTap = !isTap;
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: isTap?
                                        Text('Add to shortlist')
                                    :  Container(),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: whiteColor, width: 1.5),
                            ),
                            child: Icon(
                              isTap
                                  ? Icons.star_rounded
                                  : Icons.star_border_rounded,
                              color: whiteColor,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'ShortList'.toUpperCase(),
                          style: white10BlackTextStyle,
                        ),
                      ],
                    ),

                    ///CHAT FEATURE COMMENETED
                    // widthSpace,
                    // widthSpace,
                    // InkWell(
                    //   onTap: () => Navigator.push(
                    //     context,
                    //     MaterialPageRoute(builder: (context) => const Chat()),
                    //   ),
                    //   child: Column(
                    //     children: [
                    //       Container(
                    //         padding: const EdgeInsets.all(3),
                    //         decoration: BoxDecoration(
                    //           shape: BoxShape.circle,
                    //           border: Border.all(color: whiteColor, width: 1.5),
                    //         ),
                    //         child: Image.asset(
                    //           'assets/icons/sms.png',
                    //           color: whiteColor,
                    //           height: 18,
                    //           width: 18,
                    //         ),
                    //       ),
                    //       const SizedBox(height: 2),
                    //       Text(
                    //         'ChatNow'.toUpperCase(),
                    //         style: white10BlackTextStyle,
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    widthSpace,
                    widthSpace,
                    InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const CallScreen()),
                        );
                      },
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: whiteColor, width: 1.5),
                            ),
                            child: const Icon(
                              Icons.call,
                              color: whiteColor,
                              size: 18,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'CallNow'.toUpperCase(),
                            style: white10BlackTextStyle,
                          ),
                        ],
                      ),
                    ),
                    widthSpace,
                    widthSpace,
                    InkWell(
                      onTap: () async {
                        if (blockisTap) {
                          setState(() {
                            blockStatus = 0;
                          });

                        }
                        else {
                          setState(() {
                            blockStatus = 1;
                          });
                          shortListController.saveblockuserdata(refresh: true,
                          bp_userId: widget.userid,
                          bp_block_userId: widget.userdetaildata?.id);
                        }
                        setState(() {
                          blockisTap = !blockisTap;
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: blockisTap?
                            Text('User is Blocked')
                                : Container(),
                          ),
                        );
                      },
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: whiteColor, width: 1.5),
                            ),
                            child:  Icon(
                              blockisTap
                                  ? Icons.circle
                                  : Icons.block_rounded,
                              color: whiteColor,
                              size: 18,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Block'.toUpperCase(),
                            style: white10BlackTextStyle,
                          ),
                        ],
                      ),
                    ),
                    widthSpace,
                    widthSpace,
                    InkWell(
                      onTap: ()  {
                        showMyDialog(context);
                      },
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: whiteColor, width: 1.5),
                            ),
                            child:  Icon(
                                   Icons.report,
                              color: whiteColor,
                              size: 18,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Report'.toUpperCase(),
                            style: white10BlackTextStyle,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ];
      },
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: fixPadding * 1.5),
        children: [
          Padding(
            padding: const EdgeInsets.only(
              top: fixPadding * 2.0,
              bottom: fixPadding,
            ),
            child: Row(
              children: [
                InkWell(
                  onTap: () {
                    setState(() {
                      isSelected = 'personalInfo';
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(
                      3.9,
                      0,
                      3.9,
                      fixPadding / 3,
                    ),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                            color: isSelected == 'personalInfo'
                                ? primaryColor
                                : greyColor,
                            width: 3.5),
                      ),
                    ),
                    child: Text(
                      'Personal Info',
                      style: TextStyle(
                        color: isSelected == 'personalInfo'
                            ? primaryColor
                            : greyColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isSelected = 'religionInfo';
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(
                      3.9,
                      0,
                      3.9,
                      fixPadding / 3,
                    ),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: isSelected == 'religionInfo'
                              ? primaryColor
                              : greyColor,
                          width: 3.5,
                        ),
                      ),
                    ),
                    child: Text(
                      'Religion Info',
                      style: TextStyle(
                        color: isSelected == 'religionInfo'
                            ? primaryColor
                            : greyColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isSelected = 'preferences';
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(
                      3.9,
                      0,
                      3.9,
                      fixPadding / 3,
                    ),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: isSelected == 'preferences'
                              ? primaryColor
                              : greyColor,
                          width: 3.5,
                        ),
                      ),
                    ),
                    child: Text(
                      'Preferences',
                      style: TextStyle(
                        color: isSelected == 'preferences'
                            ? primaryColor
                            : greyColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      isSelected = 'professionalInfo';
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(
                      3.9,
                      0,
                      3.9,
                      fixPadding / 3,
                    ),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: isSelected == 'professionalInfo'
                              ? primaryColor
                              : greyColor,
                          width: 3.5,
                        ),
                      ),
                    ),
                    child: Text(
                      'Professional Info',
                      style: TextStyle(
                        color: isSelected == 'professionalInfo'
                            ? primaryColor
                            : greyColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          isSelected == 'personalInfo'
              ? personalInfo()
              : isSelected == 'religionInfo'
              ? religionInfo()
              : isSelected == 'preferences'
              ? preferences()
              : professionalInfo(),
        ],
      ),
    );
  }
  showMyDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (_) =>  AlertDialog(
          insetPadding: EdgeInsets.only(top: Get.height*0.03, bottom: Get.height*0.08, left: Get.width*0.06, right: Get.width*0.06),
          contentPadding: EdgeInsets.zero,
          scrollable: true,
          clipBehavior: Clip.antiAliasWithSaveLayer,
          shape: const RoundedRectangleBorder(
              borderRadius:
              BorderRadius.all(
                  Radius.circular(10.0))),
          content: Builder(
            builder: (context) {
              // Get available height and width of the build area of this widget. Make a choice depending on the size.
              var height = MediaQuery.of(context).size.height;
              var width = MediaQuery.of(context).size.width;
              return StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState /*You can rename this!*/){
                    return Container(
                      height: Get.height*0.64,
                      width: width,
                      padding: EdgeInsets.only(right: Get.width*0.05, left: Get.width*0.05),
                      child: Form(
                        key: _formKeyPersonal,
                        child: Column(
                          children: [
                            SizedBox(height: Get.height*0.035,),
                            Text("Report about the user",
                            style: black20BoldTextStyle,),
                            heightSpace,
                            heightSpace,
                            heightSpace,
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(
                                horizontal: fixPadding,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                border: Border.all(color: greyColor),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: TextFormField(
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return "Please enter report";
                                  }
                                  return null;
                                },
                                controller: shortListController.commentController,
                                cursorColor: primaryColor,
                                maxLines: 17,
                                style: black13MediumTextStyle,
                                decoration: const InputDecoration(
                                  //labelText: "",
                                  isDense: true,
                                  contentPadding: EdgeInsets.zero,
                                  border: UnderlineInputBorder(borderSide: BorderSide.none),
                                ),
                              ),
                            ),
                            heightSpace,
                            heightSpace,
                            InkWell(
                              onTap: (){
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.all(fixPadding * 1.5),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: primaryColor,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Text(
                                  'Cancel'.toUpperCase(),
                                  style: white16BoldTextStyle,
                                ),
                              ),
                            ),
                            heightSpace,
                            heightSpace,
                            InkWell(
                              onTap: (){
                                if (_formKeyPersonal.currentState!.validate()){
                                  shortListController.submitabsuiveuser(refresh: true,
                                  ap_userId: widget.userid,
                                  ap_abuse_userId: widget.userdetaildata?.id);
                                  Get.back();
                                }
                              },
                              child: Container(
                                padding: const EdgeInsets.all(fixPadding * 1.5),
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: primaryColor,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Text(
                                  'Save'.toUpperCase(),
                                  style: white16BoldTextStyle,
                                ),
                              ),
                            ),
                            heightSpace,
                            heightSpace,

                          ],
                        ),
                      ),
                    );
                  }
              );
            },
          ),
        )
    );
  }

  personalInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        personalDetails(),
        heightSpace,
        heightSpace,
        basicDetails(),
        heightSpace,
        heightSpace,
        habits(),
        heightSpace,
        heightSpace,
        hobbies(),
        heightSpace,
        heightSpace,
        familyDetails(),
        heightSpace,
        heightSpace,
        location(),
        heightSpace,
        heightSpace,
        contact(),
        heightSpace,
        heightSpace,
        heightSpace,
        heightSpace,
        heightSpace,
        heightSpace,

        detailButton(GlobalConstants().sendInterest, ()
        async {
         // await sendInterest();
        }),

        heightSpace,
        heightSpace,
        heightSpace,
        heightSpace,
        detailButton(
          'Upgrade to unlock contact details',
              () {
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (context) => const SubscriptionPaln()),
            // );
          },
        ),
        heightSpace,
        heightSpace,
        heightSpace,
        heightSpace,
      ],
    );
  }

  personalDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        title('Personal Information'),
        heightSpace,
        heightSpace,
        Text(
          'A Few Lines About Me',
          style: grey14BoldTextStyle,
        ),
        Text(
          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmo eiusmod tempor incididunt ut labore et dolore magna aliqua Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod...',
          style: grey13RegularTextStyle,
        ),
      ],
    );
  }

  basicDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Basic Details'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: fixPadding / 3),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Name',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-    ${widget.userdetaildata?.fristname} ${widget.userdetaildata?.middlename} ${widget.userdetaildata?.lastname}',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Age',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     25',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  habits() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Habits'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Drinking',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.userData?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                       "-    ${widget.userdetaildata?.userData?.first.pHeight}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Eating',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.userData?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.userData?.first.pDiet}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Smoking',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.userData?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.userData?.first.pSmoke}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  hobbies() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Hobbies'),
        heightSpace,
        heightSpace,
        ColumnBuilder(
          itemCount: 5,
          itemBuilder: (context, index) {
            return Padding(
              padding: EdgeInsets.only(
                  bottom: index == 5 - 1 ? 0 : fixPadding / 3),
              child: Row(
                children: [
                  Text(
                    'hobby',
                    style: grey13SemiBoldTextStyle,
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  familyDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Family Details'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Father',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.familyDetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.familyDetails?.first.fFatherName}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Mother',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.familyDetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.familyDetails?.first.fMotherName}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Bother',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     brother',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  location() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Location'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Citizenship',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     India',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Country',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.myAddressDetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.myAddressDetails?.first.aCountry}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'City',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.myAddressDetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.myAddressDetails?.first.aCity}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Lives',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     lives',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  contact() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Contact'),
        heightSpace,
        heightSpace,
        Row(
          children: [
            Expanded(
              flex: 1,
              child: Text(
                'Mobile No',
                style: grey13SemiBoldTextStyle,
              ),
            ),
            Expanded(
              flex: 2,
              child: Text(
                "-    ${widget.userdetaildata?.mobile}"??"",
                style: grey13SemiBoldTextStyle,
              ),
            ),
          ],
        ),
      ],
    );
  }

  detailButton(String btnText, void Function() btnFn) {
    return InkWell(
      onTap: btnFn,
      child: Container(
        padding: const EdgeInsets.all(fixPadding),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          btnText,
          style: white16BoldTextStyle,
        ),
      ),
    );
  }

  religionInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        title('Religion Information'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Cast',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.userData?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.userData?.first.pCaste}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              // Row(
              //   children: [
              //     Expanded(
              //       flex: 1,
              //       child: Text(
              //         'Subcast',
              //         style: grey13SemiBoldTextStyle,
              //       ),
              //     ),
              //     Expanded(
              //       flex: 2,
              //       child: Text(
              //         '-     subcast',
              //         style: grey13SemiBoldTextStyle,
              //       ),
              //     ),
              //   ],
              // ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Religion',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.userData?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.userData?.first.pReligion}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  preferences() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        title('Preferences'),
        heightSpace,
        heightSpace,
        partnerPreferences(),
        heightSpace,
        heightSpace,
        professionalPreferences(),
        heightSpace,
        heightSpace,
        religionPreferences(),
        heightSpace,
        heightSpace,
        //locationPreferences(),
        heightSpace,
        heightSpace,
      ],
    );
  }

  partnerPreferences() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Partner Preferences'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Age',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.partnerPerfernces?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.partnerPerfernces?.first.ageFrom}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Height',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     height',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Marital Status',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.partnerPerfernces?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.partnerPerfernces?.first.maritalStatus}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  professionalPreferences() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Professional Preferences'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Education',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.partnerPerfernces?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.partnerPerfernces?.first.eduction}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Occupation',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      '-     occupation',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  religionPreferences() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        subTitle('Religion Preferences'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Cast',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.partnerPerfernces?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.partnerPerfernces?.first.caste}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              // Row(
              //   children: [
              //     Expanded(
              //       flex: 1,
              //       child: Text(
              //         'Subcast',
              //         style: grey13SemiBoldTextStyle,
              //       ),
              //     ),
              //     Expanded(
              //       flex: 2,
              //       child: Text(
              //         '-    Subcast',
              //         style: grey13SemiBoldTextStyle,
              //       ),
              //     ),
              //   ],
              // ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Religicon',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.partnerPerfernces?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.partnerPerfernces?.first.religion}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  professionalInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        title('Professional Information'),
        heightSpace,
        heightSpace,
        Padding(
          padding: const EdgeInsets.only(bottom: 0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Collage Name',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduCollegeName}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Higher Education',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduHighEduSpecId}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Occupation Sector',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduOccupationSecId}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Occupation Specialization',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduOccupationSpecId}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Occupation Title',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduOccupationTitle}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Organisation Name',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduOrganisationName}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: Text(
                      'Working Destination',
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text(
                      (widget.userdetaildata?.usereducationdetails?.isNotEmpty??false) ?
                      widget.userdetaildata != null?
                      "-    ${widget.userdetaildata?.usereducationdetails?.first.uEduWorkDestination}"??"" : "":"",
                      style: grey13SemiBoldTextStyle,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )
      ],
    );
  }

  title(String title) {
    return Text(
      title,
      style: black16BoldTextStyle,
    );
  }

  subTitle(String title) {
    return Text(
      title,
      style: black14BoldTextStyle,
    );
  }
}
